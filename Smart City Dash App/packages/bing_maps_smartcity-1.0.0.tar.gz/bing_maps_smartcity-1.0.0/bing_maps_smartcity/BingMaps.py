# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class BingMaps(Component):
    """A BingMaps component.


Keyword arguments:
- bingKey (string | number; optional): API Key for Bing Maps V8 Web Control
- center (list; optional): Array containing latitude and longitude of the map center
- directions (dict; optional): Directions (needs better proptype protection)
- id (string; optional): Id to which map DOM elements will be bound to as children
- infoboxOptions (dict; optional): infoboxOptions
- mapTypeId (string; optional): Map type
https://docs.microsoft.com/en-us/bingmaps/v8-web-control/map-control-api/maptypeid-enumeration
- navigationBar (optional): Navigation bar display configuration
https://docs.microsoft.com/en-us/bingmaps/v8-web-control/map-control-api/navigationbarmode-enumeration. navigationBar has the following type: dict containing keys 'mode', 'orientation'.
Those keys have the following types: 
  - mode (a value equal to: 'compact', 'default', 'minified'; optional)
  - orientation (a value equal to: 'horizontal', 'vertical'; optional)
- polygons (list; optional): Polgons - either simple (creating points automatically) or complex (needs point input)
- polylines (list; optional): Polylines from point A to B (needs better proptype protection)
- pushpins (list; optional): Pushpins to be added to map
- selected (string; optional): Id of selected object in component (only pushpins for now)
- zoom (number; optional): Zoom level

Available events: """
    @_explicitize_args
    def __init__(self, bingKey=Component.UNDEFINED, center=Component.UNDEFINED, directions=Component.UNDEFINED, id=Component.UNDEFINED, infoboxOptions=Component.UNDEFINED, mapTypeId=Component.UNDEFINED, navigationBar=Component.UNDEFINED, polygons=Component.UNDEFINED, polylines=Component.UNDEFINED, pushpins=Component.UNDEFINED, selected=Component.UNDEFINED, zoom=Component.UNDEFINED, **kwargs):
        self._prop_names = ['bingKey', 'center', 'directions', 'id', 'infoboxOptions', 'mapTypeId', 'navigationBar', 'polygons', 'polylines', 'pushpins', 'selected', 'zoom']
        self._type = 'BingMaps'
        self._namespace = 'bing_maps_smartcity'
        self._valid_wildcard_attributes =            []
        self.available_events = []
        self.available_properties = ['bingKey', 'center', 'directions', 'id', 'infoboxOptions', 'mapTypeId', 'navigationBar', 'polygons', 'polylines', 'pushpins', 'selected', 'zoom']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(BingMaps, self).__init__(**args)

    def __repr__(self):
        if(any(getattr(self, c, None) is not None
               for c in self._prop_names
               if c is not self._prop_names[0])
           or any(getattr(self, c, None) is not None
                  for c in self.__dict__.keys()
                  if any(c.startswith(wc_attr)
                  for wc_attr in self._valid_wildcard_attributes))):
            props_string = ', '.join([c+'='+repr(getattr(self, c, None))
                                      for c in self._prop_names
                                      if getattr(self, c, None) is not None])
            wilds_string = ', '.join([c+'='+repr(getattr(self, c, None))
                                      for c in self.__dict__.keys()
                                      if any([c.startswith(wc_attr)
                                      for wc_attr in
                                      self._valid_wildcard_attributes])])
            return ('BingMaps(' + props_string +
                   (', ' + wilds_string if wilds_string != '' else '') + ')')
        else:
            return (
                'BingMaps(' +
                repr(getattr(self, self._prop_names[0], None)) + ')')

from .BingMaps import BingMaps

__all__ = [
    "BingMaps"
]